<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PW-IBIK</title>

    <link rel="stylesheet" href="<?php echo e(url('./assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('./assets/bootstrap-icons/font/bootstrap-icons.css')); ?>">

    <style>
        html,body { overflow-x: hidden; }
        body { padding-top: 56px; }
        .bg-purple{background-color: #6f42c1 !important}
    </style>
</head>

<body class="bg-body-tertiary">
    <header>
        
    </header>

    <main class="container mt-5">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="container mt-5">
        <p class="fs-7">Copyright &copy; 2023</p>
    </footer>

    <script src="<?php echo e(url('./assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</body>

</html>
<?php echo $__env->make('templates.headers.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\latihan-app\resources\views/templates/layouts.blade.php ENDPATH**/ ?>